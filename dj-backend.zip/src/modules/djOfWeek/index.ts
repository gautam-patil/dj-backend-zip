export { router as DjOfWeekRouter } from "./djOfWeek.routes";
export { Controller as DjOfWeekController } from './djOfWeek.controller';
export { DjOfWeek as DjOfWeekSchema, IDjOfWeek as IDjOfWeek} from './djOfWeek.model';
export { Dal as DjOfWeekDal } from './djOfWeek.dal'; 