export { router as AdminRouter } from "./admin.routes";
export { Controller as AdminController } from './admin.controller';
export { Admin as AdminSchema, IAdmin as IAdmin} from './admin.model';
export { Dal as AdminDal } from './admin.dal'; 